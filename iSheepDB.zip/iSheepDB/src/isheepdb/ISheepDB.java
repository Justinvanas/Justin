/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package isheepdb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;

/**
 *
 * @author James van AS
 */
public class ISheepDB {

    
    
    public static void main(String[] args) {
       
        new Login().setVisible(true);
        
        
         
    
      
    }
    }
    

